<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full'); ?>
<?php get_header(); ?>
    <?php if(get_theme_mod('universal_single_portfolio_image', 'enable')) {?>
		<div class="tag_line tag_line_image portfolio" data-background="<?php echo esc_url(get_theme_mod('universal_single_portfolio_image', get_template_directory_uri() . '/assets/images/22.jpg')); ?>">
    <?php } else { ?>
      <div class="tag_line tag_line_image portfolio" data-background="<?php echo get_template_directory_uri() . '/assets/images/22.jpg' ?>">
    <?php } ?>
		    <div class="tag-body">
		        <div class="container">
		            <div class="row">
		                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h1 class="tag_line_title"><?php echo get_theme_mod( 'universal_title_portfolio', 'Portfolio'); ?></h1>
							<div class="breadcrumbs"><a href="<?php echo home_url('/') ?>"><?php esc_html_e('Home', 'universal'); ?></a>&nbsp;/&nbsp;<span class="current"><?php echo get_theme_mod( 'universal_subtitle_portfolio', 'Single Project'); ?></span></div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
<div class="content">
	<div class="container">
		<div class="row">
			<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				<div class="wrap-content">    
	            	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				       	<h3><?php the_title() ?></h3>
						<?php the_content();?>
						<hr>
				      	<h6><i class="fa fa-user fa-fw"></i> <?php esc_html_e('Client', 'universal-wp'); ?>: <?php echo esc_attr(get_post_meta($post->ID, 'port-client', true)); ?></h6>
				      	<h6><i class="fa fa-calendar fa-fw"></i> <?php esc_html_e('Date', 'universal-wp'); ?>: <?php echo get_the_date('F j, Y') ?></h6>
				      	<h6><i class="fa fa-desktop fa-fw"></i> <?php esc_html_e('Service', 'universal-wp'); ?>: <?php echo get_post_meta($post->ID, 'port-service', 1)?></h6>
					</div>
	            	<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
	            		<div class="portfolio-single-img"><img src="<?php echo esc_url($large_image_url[0]); ?>" alt=""></div>
					</div>
				</div>
			<?php endwhile; endif;?>
		</div>
	</div>
	<div class="pagination-line">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<ul class="pager">
						<li class="previous"> <?php previous_post_link( '%link', '<i class="fa fa-angle-left"></i> ' . __( 'Previous', 'universal-wp' ) ); ?> </li>
						<li><a href="<?php echo get_theme_mod( 'universal_link_portfolio', 'http://google.com/'); ?>"><i class="fa ion-grid fa-2x"></i></a></li>
						<li class="next"> <?php next_post_link( '%link',  __( 'Next', 'universal-wp' ) . ' <i class="fa fa-angle-right"></i>'); ?> </li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<?php get_footer(); ?>



